# StoryTeller

https://JimFawcett.github.io/StoryTeller.html

Webpage that manages stories - collection of site pages that are focused on a single theme.
